package ddwu.mobile.finalproject.model;

public class GooglePlaceResponse {
    public GooglePlaceResult result;
    public String status;
}
